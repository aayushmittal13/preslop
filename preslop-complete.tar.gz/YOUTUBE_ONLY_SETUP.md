# 🎥 YouTube-Only Setup Guide

Skip Reddit entirely! Get PreSlop running with just YouTube API.

## What You'll Get

✅ Pre-2016 YouTube videos
✅ Hidden gems (low views, high quality)
✅ Deep dive content (10+ minute videos)
✅ High engagement (good like ratios)
❌ No Reddit posts (but that's okay!)

---

## Step 1: Get YouTube API Key (10 minutes)

### A. Go to Google Cloud Console
1. Visit: **https://console.cloud.google.com/**
2. Sign in with your Google account

### B. Create a Project
1. Click the **project dropdown** at the top (says "Select a project")
2. Click **"New Project"**
3. Project name: `PreSlop`
4. Click **"Create"**
5. Wait 5-10 seconds

### C. Enable YouTube Data API
1. Click **"☰ Menu"** (top left) → **"APIs & Services"** → **"Library"**
2. Search for: `YouTube Data API v3`
3. Click on **"YouTube Data API v3"**
4. Click the blue **"ENABLE"** button
5. Wait a few seconds

### D. Create API Key
1. Click **"☰ Menu"** → **"APIs & Services"** → **"Credentials"**
2. Click **"+ CREATE CREDENTIALS"** at the top
3. Select **"API key"**
4. A popup appears with your key - **COPY IT IMMEDIATELY!**

Your API key looks like:
```
AIzaSyD9xK3mN7pQ2rS4tU6vW8xY0zA1bC2dE3f
```

### E. Restrict Your Key (Recommended)
1. In the popup, click **"Restrict Key"**
2. Under "API restrictions":
   - Select **"Restrict key"**
   - Check only **"YouTube Data API v3"**
3. Click **"Save"**

✅ Done! You have your YouTube API key!

---

## Step 2: Setup Backend (5 minutes)

### A. Create .env File
In the `preslop-backend` folder, create a file named `.env`:

```env
# YouTube API Key (REQUIRED)
YOUTUBE_API_KEY=AIzaSyD9xK3mN7pQ2rS4tU6vW8xY0zA1bC2dE3f

# Reddit is OPTIONAL - you can skip it entirely!
# We're not using Reddit, so leave these commented out
```

Replace `AIzaSyD9xK3mN7pQ2rS4tU6vW8xY0zA1bC2dE3f` with your actual key!

### B. Install Dependencies
```bash
cd preslop-backend
pip install -r requirements.txt
```

---

## Step 3: Run It! (2 minutes)

### Start Backend
```bash
cd preslop-backend
python main.py
```

You should see:
```
INFO:     Uvicorn running on http://0.0.0.0:8000
```

### Test Backend
Open browser and visit: http://localhost:8000

You should see:
```json
{
  "message": "PreSlop API - Find quality pre-2016 content",
  "status": {
    "youtube": "enabled",
    "reddit": "disabled (optional)"
  }
}
```

✅ Perfect! YouTube is enabled!

### Start Frontend
Open a new terminal:

```bash
cd preslop-frontend
python -m http.server 3000
```

### Open the App
Go to: **http://localhost:3000**

🎉 **You're done!** Try searching for something!

---

## What You Can Search

Since you're using YouTube only, you'll get great pre-2016 video content:

**Try these searches:**
- "quantum mechanics lecture"
- "bread making tutorial"
- "javascript tutorial"
- "woodworking techniques"
- "jazz improvisation"
- "philosophy lecture"
- "ancient history"

---

## YouTube API Limits

**Free Tier:**
- 10,000 quota units per day
- Each search uses ~100 units
- **You get ~100 searches per day** (plenty!)
- Resets daily at midnight Pacific Time

**If you hit the limit:**
- Wait until tomorrow
- Or create another Google Cloud project with a new API key
- Or upgrade (but you won't need to for personal use)

---

## Want to Add Reddit Later?

No problem! Just:
1. Get Reddit API keys (when Reddit fixes their CAPTCHA)
2. Add them to your `.env` file:
   ```env
   REDDIT_CLIENT_ID=your_id
   REDDIT_CLIENT_SECRET=your_secret
   ```
3. Restart the backend
4. You'll now get both Reddit posts AND YouTube videos!

---

## Deployment (Make it Public)

Follow the **DEPLOYMENT_GUIDE.md** but skip the Reddit parts:

1. Push to GitHub
2. Deploy backend to Render (add only YOUTUBE_API_KEY)
3. Deploy frontend to Vercel
4. Share your URL!

---

## Troubleshooting

**"No APIs configured"**
- Your YOUTUBE_API_KEY is missing or wrong
- Check your `.env` file
- Make sure there are no extra spaces

**"API key not valid"**
- Your API key is incorrect
- Copy it again from Google Cloud Console
- Make sure you enabled YouTube Data API v3

**"Quota exceeded"**
- You've used your 10,000 daily units
- Wait until midnight Pacific Time
- Or create a new project with a new key

**No results found**
- Try different search terms
- Pre-2016 content might not exist for niche topics
- Try broader searches like "tutorial" or "lecture"

---

## Cost

**YouTube API**: FREE
- 10,000 units/day forever
- No credit card required
- No hidden fees

**Total cost**: **$0/month** ✅

---

## YouTube-Only Quality Algorithm

PreSlop finds the best pre-2016 YouTube videos using:

1. **Like Ratio** (30 pts) - High likes vs views
2. **Hidden Gem** (25 pts) - Under 10k views
3. **Length** (20 pts) - 10+ minute deep dives
4. **Age** (20 pts) - Older is better (2010-2013)
5. **Engagement** (15 pts) - Active comments

**Result**: You get the single best quality video for your search!

---

## Next Steps

✅ Get YouTube API key (done!)
✅ Setup backend (done!)
✅ Test locally (done!)
⬜ Deploy to Vercel + Render (optional)
⬜ Share with friends!
⬜ Add Reddit later (when you want)

---

**You're all set with YouTube-only PreSlop! 🎉**

No Reddit headaches, just great pre-2016 video content!
