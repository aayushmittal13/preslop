# ✅ Quick Deployment Checklist

Use this while following DEPLOYMENT_GUIDE.md

## Before You Start
- [ ] Reddit API keys ready (CLIENT_ID + CLIENT_SECRET)
- [ ] YouTube API key ready
- [ ] GitHub account created

---

## GitHub Setup (5 min)
- [ ] Create new repo: `preslop` (public)
- [ ] Push code to GitHub
  ```bash
  git init
  git add .
  git commit -m "Initial commit"
  git remote add origin https://github.com/YOUR_USERNAME/preslop.git
  git push -u origin main
  ```

---

## Backend on Render (10 min)
- [ ] Sign up at render.com with GitHub
- [ ] Create New Web Service
- [ ] Connect `preslop` repository
- [ ] Configure:
  - Root Directory: `preslop-backend`
  - Build Command: `pip install -r requirements.txt`
  - Start Command: `uvicorn main:app --host 0.0.0.0 --port $PORT`
  - Instance: Free tier
- [ ] Add environment variables:
  - `REDDIT_CLIENT_ID`
  - `REDDIT_CLIENT_SECRET`
  - `YOUTUBE_API_KEY`
- [ ] Click "Create Web Service"
- [ ] Wait for deploy (2-3 min)
- [ ] Copy your backend URL: `https://__________.onrender.com`
- [ ] Test: Visit backend URL, should see JSON message

---

## Frontend on Vercel (5 min)
- [ ] Update `preslop-frontend/index.html`:
  - Change API URL to your Render backend URL (line ~270)
- [ ] Commit and push:
  ```bash
  git add preslop-frontend/index.html
  git commit -m "Update backend URL"
  git push
  ```
- [ ] Sign up at vercel.com with GitHub
- [ ] Click "Add New" → "Project"
- [ ] Import `preslop` repository
- [ ] Configure:
  - Root Directory: `preslop-frontend`
  - Leave build settings empty
- [ ] Click "Deploy"
- [ ] Wait 30 seconds
- [ ] Copy your site URL: `https://__________.vercel.app`

---

## Test Everything
- [ ] Visit your Vercel URL
- [ ] Search for "quantum mechanics"
- [ ] Click "Surprise Me"
- [ ] Results load correctly
- [ ] Clicking result links works

---

## Share!
- [ ] Share on social media
- [ ] Tell your friends
- [ ] Post on Reddit/HN

---

## Troubleshooting Quick Fixes

**"Failed to fetch"**
→ Check backend URL in index.html matches Render URL

**"401 Unauthorized"**  
→ Re-check API keys in Render environment variables

**Backend slow/timeout**
→ Free tier sleeps after 15 min, first request takes 30s to wake up

**No results found**
→ Try different search terms, APIs might not have relevant content

---

Your URLs:
- Frontend: https://___________________
- Backend: https://___________________

🎉 Done!
