# 🚀 PreSlop - Quick Start Guide

**Your algorithm-powered pre-2016 content discovery tool is ready!**

## What You Got

✅ **Full-stack web application**
- Beautiful, distinctive UI with dark theme
- FastAPI backend with smart quality scoring
- Pure algorithmic approach (no AI runtime costs)
- Reddit + YouTube integration
- Pre-2016 content filtering

## Project Structure

```
preslop/
├── preslop-backend/
│   ├── main.py              # Backend server with API logic
│   ├── requirements.txt     # Python dependencies
│   └── .env.example         # Template for API keys
├── preslop-frontend/
│   └── index.html          # Beautiful single-page app
├── README.md               # Full documentation
├── API_SETUP_GUIDE.md      # Step-by-step API key setup
└── setup.sh                # Automated setup script
```

## 3-Step Quick Start

### 1️⃣ Get API Keys (15 minutes)
Follow `API_SETUP_GUIDE.md` to get:
- Reddit API credentials (CLIENT_ID + CLIENT_SECRET)
- YouTube API key

### 2️⃣ Install & Configure (5 minutes)
```bash
# Navigate to backend
cd preslop-backend

# Install dependencies
pip install -r requirements.txt

# Create .env file and add your API keys
cp .env.example .env
nano .env  # or use any text editor
```

### 3️⃣ Run the App (2 minutes)
```bash
# Terminal 1: Start backend
cd preslop-backend
python main.py

# Terminal 2: Start frontend
cd preslop-frontend
python -m http.server 3000

# Open browser
# Go to: http://localhost:3000
```

## What It Does

### Smart Quality Algorithm

**For Reddit Posts:**
- High engagement ratio (comments vs upvotes) = 30 points
- Long, thoughtful posts (2000+ chars) = 25 points  
- Older posts (2010-2013 era) = 20 points
- Hidden gems (low upvotes but great discussion) = 15 points

**For YouTube Videos:**
- High like ratio = 30 points
- Hidden gems (under 10k views) = 25 points
- Long videos (10+ minutes) = 20 points
- Older content (2010-2013) = 20 points
- Active comments = 15 points

### User Experience

1. **Search**: Enter any topic (e.g., "quantum mechanics", "bread making")
2. **Surprise Me**: Random quality topic discovery
3. **View Results**: See the single best result with:
   - Title and source
   - Quality badges explaining why it's good
   - Direct link to content
   - Date and engagement metrics

## Features

✨ **Pre-2016 Only** - Before the algorithm won
🎯 **Best Match** - Returns the single highest quality result
💎 **Hidden Gems** - Surfaces underrated content
📊 **Quality Badges** - Shows why content is valuable
🎨 **Beautiful UI** - Distinctive design, not generic AI slop
⚡ **Fast** - Searches Reddit + YouTube simultaneously
💰 **Free** - No AI API costs, just free Reddit + YouTube APIs

## Next Steps

### Immediate Actions:
1. ✅ Get API keys (see `API_SETUP_GUIDE.md`)
2. ✅ Run the setup script: `./setup.sh`
3. ✅ Start exploring quality content!

### Future Enhancements:
- Add Hacker News archives
- Save favorite finds
- Topic recommendations
- Weekly digest emails
- Browser extension
- Community submissions

## Technical Details

**Backend:**
- Python 3.8+ with FastAPI
- Async HTTP client (httpx)
- Reddit OAuth integration
- YouTube Data API v3
- Pure algorithmic scoring

**Frontend:**
- Vanilla HTML/CSS/JS (no framework!)
- Custom fonts (Space Mono + Crimson Pro)
- Smooth animations
- Responsive design
- Dark theme with accent colors

**APIs Used:**
- Reddit API (free, 60 req/min)
- YouTube Data API (free, 10k units/day)

**Costs:**
- **$0/month** - Everything runs on free tiers!

## Customization Ideas

### Change Search Topics
Edit the `surprise_me()` function in `main.py` to add your interests

### Adjust Quality Scoring
Modify `calculate_quality_score()` weights in `main.py`

### Update UI Theme
Edit CSS variables in `index.html` (lines 9-18)

### Add Content Sources
Extend backend to include:
- Hacker News (news.ycombinator.com)
- Stack Overflow archives
- Medium old posts
- Personal blog aggregators

## Support

**Check Documentation:**
- `README.md` - Full project documentation
- `API_SETUP_GUIDE.md` - Detailed API setup with troubleshooting
- Code comments - Inline explanations

**Common Issues:**
1. "No quality content found" → Try different search terms
2. "401 Unauthorized" → Check API keys in .env
3. "CORS error" → Access via http://localhost:3000
4. "Quota exceeded" → Wait until tomorrow (YouTube daily limit)

## Share Your Finds!

This tool is perfect for:
- 🔬 Research and learning
- ✍️ Writing inspiration
- 💡 Deep rabbit holes
- 🎓 Educational content
- 🎨 Creative projects

---

**Built for you to rediscover the internet before it became AI slop.**

Enjoy exploring the old web! 🌐✨

---

**Quick Commands Reference:**

```bash
# Setup
cd preslop-backend
pip install -r requirements.txt
cp .env.example .env
# (Add your API keys to .env)

# Run backend
python main.py

# Run frontend (separate terminal)
cd preslop-frontend
python -m http.server 3000

# Visit
open http://localhost:3000
```

That's it! You're ready to discover quality pre-2016 content! 🎉
