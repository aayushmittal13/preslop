# 🚀 Deployment Guide - Vercel + Render

Deploy PreSlop so it's accessible from anywhere on the internet!

## Overview

We'll deploy:
- **Backend** on Render.com (free tier)
- **Frontend** on Vercel (free tier)
- **Total Cost**: $0/month forever

## Prerequisites

✅ GitHub account (free)
✅ Reddit API keys (from API_SETUP_GUIDE.md)
✅ YouTube API key (from API_SETUP_GUIDE.md)

---

## Part 1: Push Code to GitHub (5 minutes)

### Step 1: Create GitHub Repository

1. Go to https://github.com/new
2. Repository name: `preslop`
3. Description: `Find quality pre-2016 content`
4. Select **Public** (required for free Vercel/Render)
5. DON'T check "Add README" (we already have one)
6. Click **"Create repository"**

### Step 2: Push Your Code

Open terminal in your project folder:

```bash
# Initialize git (if not already done)
git init

# Add all files
git add .

# Commit
git commit -m "Initial commit - PreSlop app"

# Add your GitHub repo as remote (replace YOUR_USERNAME)
git remote add origin https://github.com/YOUR_USERNAME/preslop.git

# Push to GitHub
git branch -M main
git push -u origin main
```

**Important**: Make sure you didn't accidentally commit your `.env` file! 
Check `.gitignore` includes `.env`

---

## Part 2: Deploy Backend on Render (10 minutes)

### Step 1: Create Render Account

1. Go to https://render.com/
2. Click **"Get Started"**
3. Sign up with **GitHub** (easiest)
4. Authorize Render to access your repos

### Step 2: Create New Web Service

1. Click **"New +"** button (top right)
2. Select **"Web Service"**
3. Click **"Build and deploy from a Git repository"**
4. Click **"Connect"** next to your `preslop` repository
   - If you don't see it, click "Configure account" and grant access

### Step 3: Configure Service

Fill in these settings:

**Basic Settings:**
- **Name**: `preslop-backend` (or any name you want)
- **Region**: Choose closest to you
- **Branch**: `main`
- **Root Directory**: `preslop-backend`
- **Runtime**: `Python 3`
- **Build Command**: `pip install -r requirements.txt`
- **Start Command**: `uvicorn main:app --host 0.0.0.0 --port $PORT`

**Instance Type:**
- Select **"Free"** (0.1 CPU, 512 MB RAM)

### Step 4: Add Environment Variables

Scroll down to **"Environment Variables"** section:

Click **"Add Environment Variable"** and add:

**Required:**
1. **Key**: `YOUTUBE_API_KEY`
   **Value**: (your YouTube API key)

**Optional (skip if you don't have Reddit keys):**
2. **Key**: `REDDIT_CLIENT_ID`
   **Value**: (your Reddit client ID - leave empty if skipping)

3. **Key**: `REDDIT_CLIENT_SECRET`
   **Value**: (your Reddit client secret - leave empty if skipping)

**Note**: You can run PreSlop with ONLY YouTube! Reddit is optional.

### Step 5: Deploy!

1. Click **"Create Web Service"** button at bottom
2. Wait 2-3 minutes for deployment
3. You'll see logs - wait for "Application startup complete"
4. Copy your backend URL (looks like: `https://preslop-backend-xxxx.onrender.com`)

**⚠️ Important**: Your backend URL will be different! Save it for next step.

### Step 6: Test Backend

Visit: `https://your-backend-url.onrender.com/`

You should see:
```json
{"message": "PreSlop API - Find quality pre-2016 content"}
```

✅ Backend is live!

---

## Part 3: Deploy Frontend on Vercel (5 minutes)

### Step 1: Update API URL in Frontend

Before deploying frontend, update the backend URL:

1. Open `preslop-frontend/index.html`
2. Find this line (around line 270):
   ```javascript
   : 'https://preslop-backend.onrender.com'; // Replace with your actual Render URL
   ```
3. Replace with YOUR actual Render backend URL
4. Save the file
5. Commit and push:
   ```bash
   git add preslop-frontend/index.html
   git commit -m "Update backend URL for production"
   git push
   ```

### Step 2: Create Vercel Account

1. Go to https://vercel.com/
2. Click **"Sign Up"**
3. Choose **"Continue with GitHub"**
4. Authorize Vercel

### Step 3: Deploy Frontend

1. Click **"Add New..."** → **"Project"**
2. Find your `preslop` repository
3. Click **"Import"**

**Configure Project:**
- **Framework Preset**: Other (leave as is)
- **Root Directory**: Click "Edit" → enter `preslop-frontend`
- **Build Settings**: Leave empty (static site)
- Click **"Deploy"**

### Step 4: Wait for Deployment

- Takes 30-60 seconds
- You'll see confetti 🎉 when done!
- You get a URL like: `https://preslop-xxxxx.vercel.app`

### Step 5: Test Your Site!

1. Click the deployment URL
2. Try searching for "quantum mechanics"
3. Click "Surprise Me"

✅ **Your site is LIVE!** 🎉

---

## Part 4: Custom Domain (Optional)

### For Vercel Frontend:

1. In Vercel dashboard, go to your project
2. Click **"Settings"** → **"Domains"**
3. Add your domain (e.g., `preslop.com`)
4. Follow DNS instructions from your domain registrar

### For Render Backend:

1. In Render dashboard, go to your service
2. Click **"Settings"** → **"Custom Domain"**
3. Add your domain (e.g., `api.preslop.com`)
4. Follow DNS instructions

**Free Domain Options:**
- Freenom.com (free .tk, .ml, .ga domains)
- GitHub Student Pack (free .me domain via Namecheap)
- Or buy cheap domain (~$10/year)

---

## Troubleshooting

### Backend Issues

**"Application failed to respond"**
- Check Render logs for errors
- Verify environment variables are set correctly
- Make sure build command ran successfully

**"401 Unauthorized" errors**
- Your API keys are wrong
- Double-check Reddit/YouTube credentials
- Re-add environment variables in Render

**Backend keeps sleeping**
- Free tier sleeps after 15 min inactivity
- First request after sleep takes 30-60 seconds
- Upgrade to paid tier ($7/mo) for always-on

### Frontend Issues

**"Failed to fetch" or CORS errors**
- Your backend URL in index.html is wrong
- Check it matches your Render URL exactly
- Include `https://` in the URL

**Can't find backend**
- Make sure backend is deployed and running
- Test backend URL directly in browser
- Check Render dashboard shows "Live"

### API Rate Limits

**YouTube quota exceeded**
- Free tier: 10,000 units/day
- Each search: ~100 units
- Resets daily at midnight PT
- Solution: Create multiple YouTube projects with different API keys

**Reddit rate limits**
- Free tier: 60 requests/min
- Should be plenty for personal use
- If hit, wait 1 minute

---

## Monitoring & Maintenance

### Check Backend Status
Visit: `https://your-backend-url.onrender.com/`

### View Backend Logs
1. Go to Render dashboard
2. Click on your service
3. Click "Logs" tab

### Update Your App
```bash
# Make changes to code
git add .
git commit -m "Your changes"
git push

# Both Vercel and Render auto-deploy on push!
```

### Free Tier Limits

**Render Free Tier:**
- 750 hours/month (enough for 24/7 in one service)
- Sleeps after 15 min inactivity
- 400 build minutes/month
- ✅ Perfect for personal projects

**Vercel Free Tier:**
- 100 GB bandwidth/month
- Unlimited deployments
- 100 builds/day
- ✅ More than enough

---

## Upgrade Options (If Needed)

### If You Get Popular:

**Render Paid** ($7/month):
- Always-on (no sleeping)
- More RAM/CPU
- Better performance

**Vercel Pro** ($20/month):
- More bandwidth
- Team features
- Custom analytics

**But for now**: Free tier is perfect! 🎉

---

## Security Best Practices

✅ **Never commit .env files** (already in .gitignore)
✅ **Use environment variables** for API keys
✅ **Keep dependencies updated** (`pip install -U`)
✅ **Monitor API usage** (check Google/Reddit dashboards)
✅ **Set up API key restrictions** (YouTube API settings)

---

## Your Deployed URLs

After following this guide, fill in:

- **Frontend**: https://_______________.vercel.app
- **Backend**: https://_______________.onrender.com
- **Custom Domain** (if added): https://_______________

---

## Success Checklist

- [ ] Code pushed to GitHub
- [ ] Backend deployed on Render
- [ ] Environment variables added
- [ ] Backend URL updated in frontend
- [ ] Frontend deployed on Vercel
- [ ] Site works when you visit it
- [ ] Search returns results
- [ ] "Surprise Me" works
- [ ] Shared URL with friends!

---

## Next Steps

🎉 **Congrats! Your site is live!**

Share it:
- Post on Reddit: r/internetisbeautiful
- Share on Twitter/X with hashtag #PreSlop
- Show Hacker News
- Tell your friends!

Improve it:
- Add more content sources
- Implement user accounts
- Save favorite finds
- Create weekly digest emails
- Build browser extension

---

## Need Help?

**Render Support**:
- Docs: https://render.com/docs
- Community: https://community.render.com/

**Vercel Support**:
- Docs: https://vercel.com/docs
- Discord: https://vercel.com/discord

**GitHub Issues**:
Create an issue in your repo if you find bugs!

---

**You're now running a live website accessible from anywhere! 🌐✨**
