#!/bin/bash

echo "🚀 PreSlop Setup Script"
echo "======================="
echo ""

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is not installed. Please install Python 3.8+ first."
    exit 1
fi

echo "✅ Python found: $(python3 --version)"
echo ""

# Setup backend
echo "📦 Setting up backend..."
cd preslop-backend

# Install dependencies
echo "Installing Python dependencies..."
pip3 install -r requirements.txt

# Check if .env exists
if [ ! -f .env ]; then
    echo ""
    echo "⚠️  No .env file found. Creating from template..."
    cp .env.example .env
    echo ""
    echo "📝 Please edit preslop-backend/.env and add your API keys:"
    echo "   1. Reddit: REDDIT_CLIENT_ID and REDDIT_CLIENT_SECRET"
    echo "   2. YouTube: YOUTUBE_API_KEY"
    echo ""
    echo "See README.md for instructions on getting API keys."
    echo ""
    read -p "Press Enter after you've added your API keys..."
fi

echo ""
echo "✅ Backend setup complete!"
echo ""
echo "🎉 PreSlop is ready to use!"
echo ""
echo "To start the app:"
echo "  1. Start backend:  cd preslop-backend && python3 main.py"
echo "  2. Start frontend: cd preslop-frontend && python3 -m http.server 3000"
echo "  3. Open browser:   http://localhost:3000"
echo ""
