# API Keys Setup Guide

This guide walks you through getting the required API keys for PreSlop.

## Reddit API Setup (5 minutes)

### Step 1: Go to Reddit Apps Page
Navigate to: https://www.reddit.com/prefs/apps

(You need to be logged into Reddit)

### Step 2: Create New App
Scroll to the bottom and click **"create another app..."**

### Step 3: Fill in the Form
- **Name**: `PreSlop` (or any name you want)
- **App type**: Select **"script"** (radio button)
- **Description**: `Personal content discovery tool`
- **About URL**: (leave this blank)
- **Redirect URI**: `http://localhost:8000`

### Step 4: Create App
Click **"create app"** button at the bottom

### Step 5: Get Your Credentials
You'll see your new app. Under the name, you'll see:
- A string of random characters (this is your **CLIENT_ID**)
- Below "secret", another string (this is your **CLIENT_SECRET**)

**Example:**
```
personal use script
dF8k2jS9mN4pQ1r    <-- This is CLIENT_ID
secret
xY9zW3vB7cN2mL5kP4qR8sT1uV6wX0y   <-- This is CLIENT_SECRET
```

Copy both and save them for later!

---

## YouTube API Setup (10 minutes)

### Step 1: Go to Google Cloud Console
Navigate to: https://console.cloud.google.com/

(You need a Google account)

### Step 2: Create a Project (if you don't have one)
1. Click the project dropdown at the top (says "Select a project")
2. Click **"New Project"**
3. Enter project name: `PreSlop`
4. Click **"Create"**
5. Wait a few seconds for it to be created

### Step 3: Enable YouTube Data API
1. In the left sidebar, click **"APIs & Services"** > **"Library"**
2. In the search box, type: `YouTube Data API v3`
3. Click on **"YouTube Data API v3"**
4. Click the blue **"Enable"** button
5. Wait for it to enable (takes 5-10 seconds)

### Step 4: Create API Key
1. In the left sidebar, click **"APIs & Services"** > **"Credentials"**
2. Click **"+ Create Credentials"** at the top
3. Select **"API Key"**
4. A popup will show your API key - **copy it immediately!**

**Example:**
```
AIzaSyD9xK3mN7pQ2rS4tU6vW8xY0zA1bC2dE3f   <-- Your API Key
```

### Step 5: Restrict the Key (Recommended for Security)
1. Click **"Restrict Key"** in the popup (or edit it later)
2. Under "API restrictions":
   - Select **"Restrict key"**
   - Check only **"YouTube Data API v3"**
3. Click **"Save"**

### Step 6: Check Your Quota
- Free tier: 10,000 units per day
- Each search uses ~100 units
- This gives you ~100 searches per day (plenty for personal use!)

---

## Add Keys to Your App

### Step 1: Create .env File
In the `preslop-backend` folder, create a file named `.env`

### Step 2: Add Your Keys
Copy this template and replace with your actual keys:

```env
# Reddit API Credentials
REDDIT_CLIENT_ID=dF8k2jS9mN4pQ1r
REDDIT_CLIENT_SECRET=xY9zW3vB7cN2mL5kP4qR8sT1uV6wX0y

# YouTube API Key  
YOUTUBE_API_KEY=AIzaSyD9xK3mN7pQ2rS4tU6vW8xY0zA1bC2dE3f
```

**Important:**
- Don't add quotes around the values
- Don't share this file with anyone
- Don't commit it to git (it's already in .gitignore)

### Step 3: Save and Close
Save the `.env` file. You're done!

---

## Testing Your Keys

### Test Reddit API:
```bash
curl -X POST http://localhost:8000/search \
  -H "Content-Type: application/json" \
  -d '{"query": "test", "content_type": "text"}'
```

### Test YouTube API:
```bash
curl -X POST http://localhost:8000/search \
  -H "Content-Type: application/json" \
  -d '{"query": "test", "content_type": "video"}'
```

If you get results, your keys are working! 🎉

---

## Troubleshooting

### Reddit API Issues

**Error: "401 Unauthorized"**
- Your CLIENT_ID or CLIENT_SECRET is wrong
- Double-check you copied both correctly
- Make sure there are no extra spaces

**Error: "403 Forbidden"**
- Your app type might be wrong (should be "script")
- Try recreating the app

### YouTube API Issues

**Error: "API key not valid"**
- Your API key is wrong or has typos
- Make sure you copied the entire key
- Check if the key is restricted to the wrong API

**Error: "Quota exceeded"**
- You've used all 10,000 units for today
- Resets at midnight Pacific Time
- Consider multiple API keys or wait until tomorrow

**Error: "Access Not Configured"**
- You didn't enable the YouTube Data API v3
- Go back to Google Cloud Console and enable it

---

## Security Best Practices

1. **Never share your .env file**
2. **Never commit .env to git** (it's in .gitignore)
3. **Restrict your API keys** to specific APIs
4. **Rotate keys periodically** (every few months)
5. **Delete unused keys** from Google/Reddit

---

## Cost Information

### Reddit API
- **Cost**: FREE forever
- **Rate Limit**: 60 requests per minute
- **Daily Limit**: Effectively unlimited for personal use

### YouTube API
- **Cost**: FREE (with limits)
- **Daily Quota**: 10,000 units
- **Per Search**: ~100 units = ~100 searches/day
- **Overage**: You can request quota increase or pay ($0 for personal use)

**Bottom Line**: Completely free for personal use! 🎉

---

## Need Help?

Common issues and solutions:

1. **"No module named 'fastapi'"**
   - Run: `pip install -r requirements.txt`

2. **"Connection refused"**
   - Make sure backend is running: `python main.py`

3. **"CORS error"**
   - Access frontend via `http://localhost:3000`, not `file://`

4. **"No results found"**
   - Try different search terms
   - Check if APIs are working (see Testing section above)

Still stuck? Check the main README.md or the code comments!
